
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `passwords` varchar(20) DEFAULT NULL,
  `confpass` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `birthdate` varchar(20) DEFAULT NULL,
  `user_leve` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `passwords`, `confpass`, `phone`, `country`, `address`, `birthdate`, `user_leve`) VALUES
(1, 'mariam', 'tarek', 'mariam@gmail.com', '1234567890', '1234567890', '01234567890', 'egypt', 'maadi', '31/7/2000', 0),
(2, 'Maya', 'muhamed', 'maya@gmail.com', '1234567891011', '1234567891011', '', NULL, NULL, NULL, 0),
(4, 'muhamed', 'mahmoud', 'muhamed@gmail.com', '1234567891011', '1234567891011', '01234567891', NULL, NULL, NULL, 0),
(5, 'manar', 'tarek', 'manar@gmail.com', 'asdfghjkll', 'asdfghjkll', '01122334466', 'egypt', 'maadi', '0000-00-00', 0),
(6, 'admin', NULL, 'admin@gmail.com', '1122334455667788', '1122334455667788', NULL, NULL, NULL, NULL, 1);
