
-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `ename` varchar(30) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `enumber` varchar(30) DEFAULT NULL,
  `epassword` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `ename`, `email`, `enumber`, `epassword`, `address`) VALUES
(1, 'Muhamed Ahmed', 'muhamed12@triplet.com', '01234578900', 'muhamed1234', 'Nasr city');
